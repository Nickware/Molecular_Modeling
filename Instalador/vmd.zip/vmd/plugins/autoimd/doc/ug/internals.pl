# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/fig:simsettings-GUI/;
$ref_files{$key} = "$dir".q|ug.html|; 
$noresave{$key} = "$nosave";

$key = q/par:params/;
$ref_files{$key} = "$dir".q|ug.html|; 
$noresave{$key} = "$nosave";

$key = q/par:customize/;
$ref_files{$key} = "$dir".q|ug.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:autoimd-GUI/;
$ref_files{$key} = "$dir".q|ug.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:autoimd-diagram/;
$ref_files{$key} = "$dir".q|ug.html|; 
$noresave{$key} = "$nosave";

1;

