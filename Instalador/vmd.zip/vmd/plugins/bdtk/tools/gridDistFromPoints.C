#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <omp.h>

#include "useful.H"
#include "Grid.H"
#include "Scatter.H"
#include "CellDecomposition.H"

using namespace std;

int main(int argc, char* argv[]) {

	if ( argc != 4 ) {
		printf("Description: Prepare a grid (dx file) of minimum distances to the list of points.\n");
		printf("   Usage:\t%s sources_xyz.txt outGrid\n", argv[0]);
		printf("Parameters:\n");
		printf("   sources_xyz - data points.\n");
		printf("   resolution  - grid resolution.\n");
		printf("   outGrid      - output file.\n");
		printf("You have provided: %d arguments!", argc);

		return 0;
	}

	omp_set_num_threads(omp_get_max_threads()); // Use all OMP threads
	printf("->  Running %d thread(s)\n", omp_get_max_threads());

	// Read input
	const char* filename = argv[1];
	const double resolution = strtod(argv[2], NULL);
	const char* outGrid	 = argv[argc-1];

	Scatter points(filename);
	const int surfNum = points.length();
	Vector3* surfPos = new Vector3[surfNum];
	for (int i = 0; i < surfNum; ++i)
		surfPos[i] = points.get(i);

	Vector3 points_min = points.minBound();
	Vector3 points_max = points.maxBound();
	Grid source(points_min, points_max, resolution);

	// Load the grid
	const long long size = source.length();

	// Get and store system geometry
	Matrix3 sys    = source.getBox();
	Vector3 origin = source.getOrigin();
	Vector3 extent = source.getExtent();
	Vector3 res    = source.getResolution();
	printf("->  Determined system geometry, origin, extent and resolution.\n");

	// Determine "nlevels" - number of decomposition levels

	int nlevels    =  0;
	int ncellslast = -1;

	double cutoff = 0.5 * extent.length();
	while (cutoff >= 3.0 * res.length()) {

		CellDecomposition* cell = new CellDecomposition(sys,origin,cutoff);
		int ncells = cell->length(); // number of cells, nx*ny*nz
		if (ncells != ncellslast) {
			nlevels++;
			ncellslast = ncells;
		}
		delete cell;
		cutoff *= 0.5; // decrease the number of grid points in cell volume by 2 (2**1/3)

	}

	// Create cell decompositions
	CellDecomposition** cell = new CellDecomposition*[nlevels];

	int level = 0;
	cutoff = 0.5 * extent.length();

#pragma omp master
	while (level < nlevels) {
		cell[level] = new CellDecomposition(sys, origin, cutoff);
		cutoff *= 0.5;
		if (level > 0 && cell[level]->length() == cell[level-1]->length()) {
			delete cell[level];
			continue;
		}
		cell[level]->decompose(surfPos, surfNum);
		level++;
	}

	printf("->  Generated %d cell decompositions.\n", nlevels);


	// Prepare output grid
	// source -> currently = 0 for outside the membrane; 1 - otherwise
	Grid dest(source);

	//nlevels = 1;
	long long counter = 0;
	double complete = 0;
	double start_time = omp_get_wtime();
	double last_time = start_time;

	printf("\n");
#pragma omp parallel for
	for (long long i = 0; i < size; i++) {

		Vector3 r = source.getPosition(i);

		IndexList neigh;
		int nNeighs = 0;
		int level = nlevels;


		// Go down in decompositions until the minimum distanse is found
		while (true) {
			level--;
			if (level == -1) break;

			neigh = cell[level]->neighborhood(r); // Get the indices (in pos) of possible neighboring points.
			nNeighs = neigh.length();

			if (nNeighs < 1)
				continue;

			// Get decomposition resolution
			Vector3 res = cell[level]->Grid::getResolution();
			double reslength2 = res.length2();

			// Distance to the first point from the list of surface points.
			double minDist = 0.0;

			// Now, find the minimum distance
			for (int j = 0; j < nNeighs; j++) {
				Vector3 dd = source.wrapDiff(surfPos[neigh.get(j)] - r);

				// If this neighbor is obviously too far, go to the next
				if (fabs(dd.x) > res.x || fabs(dd.y) > res.y || fabs(dd.z) > res.z) continue; // jump to the next neighbor

				// Ok, check if the distance is reasonable (max = 0.5*reslength, max^2 = 0.25*reslength^2)
				double curDist = dd.length2();
				if (level!=0)
					if (curDist > 0.25*reslength2)
						continue; // jump to the next neighbor

				// If this is the first neighbor that satisfies all the conditions
				// remember it and continue
				if (minDist == 0.0) { minDist = curDist; continue; }

				// If this is not the first neighbor, compare to previous enarest neighbor
				minDist = (curDist > minDist) ? minDist : curDist;
			}

			// If this cell decomposition hasn't revealved resonable neighbor
			// go lower in decomposition
			if (minDist == 0)
				continue; // jump to lower decomposition level

			// Doublecheck calculations of every 1000-th node
			// Do it only if decomposition-based search did not use the lowest level
			if (i % 1000 == 0 && level != 1) {
				neigh = cell[1]->neighborhood(r); // Get the indices of all surface points
				nNeighs = neigh.length();

				// Distance to the first point from the list of surface points.
				Vector3 d =  source.wrapDiff(surfPos[neigh.get(0)] - r);
				double minDist2 = d.length2();

				// Now, find the minimum distance
				for (int j = 1; j < nNeighs; j++) {
					Vector3 dd = source.wrapDiff(surfPos[neigh.get(j)] - r);
					double curDist = dd.length2();
					minDist2 = (curDist > minDist2) ? minDist2 : curDist;
				}

				// Compare to decomposition-based search
				if (minDist != minDist2)
					printf("Point %lld, level %d, diff: %f, res: %f %f %f\n",i,level, sqrt(abs(minDist - minDist2)), res.x, res.y, res.z);
			}

			// Set the value to minimum distance
			dest.setValue(i, sqrt(minDist));

			break; // do not go to the next decomposition level,
		}


		// Display status in the terminal, if necessary
		if (1) {

			// This thread (node) has done its job. 
			// Increment the progress counter and let user know about it

#pragma omp atomic
			++counter;

#pragma omp critical
			{
				// Current progress
				double comp = (100.0*counter)/size;

				// Update status only if significant progress has been made
				if (comp-complete >= 0.01) {

					// Get current time
					double current_time = omp_get_wtime();

					// Limit the rate of status update to 25 times per second (25*0.04 = 1s)
					if (current_time - last_time > 0.04) {
						double run_time = current_time - start_time;

						double remain_time = run_time * (100 - comp) / comp;
						int hrs2 = (int)(remain_time/3600.0);
						int min2 = (int)((remain_time-hrs2*3600.0)/60.0);
						int sec2 = remain_time - hrs2*3600.0 - min2*60.0;

						printf("\rComplete: %6.2f%% (Remaining: %02d:%02d:%02d)", comp, hrs2, min2, sec2);
						fflush(stdout);

						// Remember the time of status update
						last_time = current_time;

						// Remember the progress
						complete = comp;
					}
				}
			}
		}



	}

	double run_time = omp_get_wtime() - start_time;
	int hrs = (int)(run_time/3600.0);
	int min = (int)((run_time-hrs*3600.0)/60.0);
	int sec = run_time - hrs*3600.0 - min*60.0;
	printf("\rComplete 100%%. Completed in %02d:%02d:%02d    \n", hrs, min, sec);

	delete[] surfPos;
	for (int level = 0; level < nlevels; ++level) delete cell[level];
	delete[] cell;

	char comments[256];
	sprintf(comments, "Distance to points from %s",filename);
	dest.write(outGrid, comments);
	printf("Wrote -> %s\n", outGrid);

	return 0;
}
