#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <omp.h>

#include "useful.H"
#include "Grid.H"
#include "TabulatedPotential.H"

using namespace std;

int main(int argc, char* argv[]) {
	if ( argc != 4 ) {
		printf("Usage: %s srcGrid potentialData.dat outGrid\n", argv[0]);
		return 0;
	}

	// Read input
	const char* srcGrid		= argv[1];
	const char* potDataFile	= argv[2];
	const char* outGrid		= argv[argc-1];

	// Potential object
	TabulatedPotential pot(potDataFile);
	printf("-> Created potential object\n");

	double minimumDistance = pot.firstPosition();
	double maximumDistance = pot.lastPosition();
	double barrierHeight1 = pot.computeEnergy(minimumDistance);  // "Maximum" value (assumed to be at minimum r)
	double barrierHeight2 = pot.computeEnergy(maximumDistance);  // "Minimum" value (assumed to be at maximum r)
	double dr = pot.getInterval();                              // Data spacing

	printf("Tabulated potential:\n");
	printf("->  Data spacing:  %g\n", dr);
	printf("->  At minimum r:  %g\n", barrierHeight1);
	printf("->  At maximum r:  %g\n", barrierHeight2);


	// Distance grid
	Grid source(srcGrid);
	printf("-> Loaded distance grid: %s\n", srcGrid);

	Grid dest(srcGrid);

	const long long size = source.length();
	
	#pragma omp critical
	for (long long i = 0; i < size; i++) {

		double d = source.getValue(i);
		double value = 0.0;

		if (d < minimumDistance) 
			value = barrierHeight1;
		else if (d <= maximumDistance)
			value = pot.computeEnergy(d); // why (d+ 2.0dr)?
		else
			value = barrierHeight2;

		dest.setValue(i, value);
	}

	char comments[256];
	sprintf(comments, "Distance grid: %s. PotentialFile %s", srcGrid, potDataFile);
	dest.write(outGrid, comments);
	printf("Wrote `%s'.\n", outGrid);

	return 0;
}
