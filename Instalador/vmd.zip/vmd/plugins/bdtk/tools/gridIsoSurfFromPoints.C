#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <omp.h>

#include "useful.H"
#include "Grid.H"
#include "Scatter.H"

using namespace std;

int main(int argc, char* argv[]) {

	if ( argc != 4 && argc !=6 ) {
		printf("Description: Prepare a grid (dx file) of minimum distances to the list of points.\n");
		printf("   Usage:\t%s sources_xyz.txt resolution[.x resolution.y resolution.z] outGrid\n", argv[0]);
		printf("Parameters:\n");
		printf("   sources_xyz - data points.\n");
		printf("   resolution  - grid resolution.\n");
		printf("   outGrid      - output file.\n");
		printf("You have provided: %d arguments!", argc);

		return 0;
	}

	omp_set_num_threads(omp_get_max_threads()); // Use all OMP threads
	printf("->  Running %d thread(s)\n", omp_get_max_threads());

	// Read input
	const char* filename = argv[1];
	const char* outGrid	 = argv[argc-1];

	const double resolution = strtod(argv[2], NULL);

	Scatter points(filename);
	const int surfNum = points.length();
	Vector3* surfPos = new Vector3[surfNum];
	for (int i = 0; i < surfNum; ++i)
		surfPos[i] = points.get(i);

	Vector3 points_min = points.minBound();
	Vector3 points_max = points.maxBound();
	Grid source(points_min, points_max, resolution);

	// Load the grid
	const long long size = source.length();



	// Prepare output grid
	// source -> currently = 0 for outside the membrane; 1 - otherwise

	long long counter = 0;
	double complete = 0;
	double start_time = omp_get_wtime();
	double last_time = start_time;

	printf("\n");

	const double sigma = 1.0;
	const double a = 0.5 / (sigma * sigma); 
	const double b = pow(a / M_PI, 1.5);

	for (long long i = 0; i < size; ++i) {
		Vector3 r = source.getPosition(i);
		for (int p = 0; p < surfNum; ++p) {
			Vector3 point = surfPos[p]; // points.get(p);
			Vector3 d = point - r;
			double dist = d.length2();
			double addvalue =  b * exp(-a*dist);
			source.incrValue(i, addvalue);
		}

		// Display status in the terminal, if necessary
		if (1) {

			// This thread (node) has done its job. 
			// Increment the progress counter and let user know about it

#pragma omp atomic
			++counter;

#pragma omp critical
			{
				// Current progress
				double comp = (100.0*counter)/size;

				// Update status only if significant progress has been made
				if (comp-complete >= 0.01) {

					// Get current time
					double current_time = omp_get_wtime();

					// Limit the rate of status update to 25 times per second (25*0.04 = 1s)
					if (current_time - last_time > 0.04) {
						double run_time = current_time - start_time;

						double remain_time = run_time * (100 - comp) / comp;
						int hrs2 = (int)(remain_time/3600.0);
						int min2 = (int)((remain_time-hrs2*3600.0)/60.0);
						int sec2 = remain_time - hrs2*3600.0 - min2*60.0;

						printf("\rComplete: %6.2f%% (Remaining: %02d:%02d:%02d)", comp, hrs2, min2, sec2);
						fflush(stdout);

						// Remember the time of status update
						last_time = current_time;

						// Remember the progress
						complete = comp;
					}
				}
			}
		}
	}

	// Find minimum value across all xy layers
	const int nx = source.getNx();
	const int ny = source.getNy();
	const int nz = source.getNz();

	for (int ix = 0; ix < nx; ++ix)
		for (int iy = 0; iy < ny; ++iy) {
			double minVal = source.getValue(ix, iy, 0);

			for (int iz = 1; iz < nz; ++iz) {
				double v = source.getValue(ix, iy, iz);
				if (v < minVal) minVal = v;
			}

			for (int iz = 0; iz < nz; ++iz)
				source.setValue(ix, iy, iz, minVal);
		}


	double run_time = omp_get_wtime() - start_time;
	int hrs = (int)(run_time/3600.0);
	int min = (int)((run_time-hrs*3600.0)/60.0);
	int sec = run_time - hrs*3600.0 - min*60.0;
	printf("\rComplete 100%%. Completed in %02d:%02d:%02d    \n", hrs, min, sec);

	delete[] surfPos;

	char comments[256];
	sprintf(comments, "Distance to points from %s",filename);
	source.write(outGrid, comments);
	printf("Wrote -> %s\n", outGrid);

	return 0;
}
