#include <cmath>
#include <cstdio>

using namespace std;

#include "useful.H" 	// Basic types (Vector/Matrix)
#include "Grid.H"		// Basic operations with grids and DX files
#include "Scatter.H"	// For reading "basis" file

int main(int argc, char* argv[]) {

	if ( argc != 4 && argc != 6 ) {
		printf("Make a new grid (all zeros) from a basis file and desired grid resolution.\n");
		printf("basisFile lists the cell basis vectors (a, b, c), and, optionally, grid center which defaults to (0,0,0):\n");
		printf("ax ay az\n");
		printf("bx by bz\n");
		printf("cx cy cz\n");
		printf("ox oy oz\n");
		printf("\nUsage: %s basisFile gridSpacingX [gridSpacingY gridSpacingZ] outGrid\n", argv[0]);
		return 0;
	}

	const char* basisFile = argv[1];
	const double gridSpacingX = strtod(argv[2], NULL);
	const char* outputFile = argv[argc-1];

	// Read input
	Scatter sysVec(basisFile);			// Read basis file.
	Matrix3 box = sysVec.topMatrix();	// First 3 rows in basis file

	Vector3 center = Vector3(0.0);
	if (sysVec.length() > 3)
		center = sysVec.get(3);		// Fourth row in basis file.

	Grid* dataGrid;
	Vector3 resolution = Vector3(gridSpacingX);

	if (argc == 6) {
		resolution.y = strtod(argv[3], NULL);
		resolution.z = strtod(argv[4], NULL);
	}

	// printf("Grid resolution: %g %g %g\n", resolution.x, resolution.y, resolution.z);

	dataGrid = new Grid(box, center, resolution);

	char comments[256];
	sprintf(comments, "Grid with basis from %s", basisFile);
	printf("Initiating output to: %s", outputFile);
	fflush(stdout);
	dataGrid->write(outputFile, comments);
	printf(" - done!");

	delete dataGrid;
	return 0;
}
