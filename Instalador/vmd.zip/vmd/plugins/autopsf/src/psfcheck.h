#ifndef _PSFCHECK
#define _PSFCHECK

int psfupdate(char*, char*, char*); 

#endif
