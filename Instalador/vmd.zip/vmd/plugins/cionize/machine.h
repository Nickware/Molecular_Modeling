/* 
 * machine.h - This is the machine specific include file
 *
 *  $Id: machine.h,v 1.1 2006/11/14 19:37:10 petefred Exp $
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

