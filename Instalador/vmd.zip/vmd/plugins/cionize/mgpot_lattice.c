/*
 * Copyright (C) 2007 by David J. Hardy.  All rights reserved.
 *
 * mgpot_lattice.c
 *
 * Expand lattice class methods.
 */

#include "mgpot_lattice.h"

LATTICE_CLASS_METHODS(float)
