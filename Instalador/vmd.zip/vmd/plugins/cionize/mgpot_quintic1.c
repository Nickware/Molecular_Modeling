/*
 * Copyright (C) 2007 by David J. Hardy.  All rights reserved.
 *
 * mgpot_quintic1.c - smooth quintic C1 interpolant
 */

#include "mgpot_defn.h"

int mgpot_longrng_quintic1(Mgpot *mg) {
  return ERROR("not yet implemented\n");
}
